# intentionally kept dictionaries here for a more robust data structure
class Lemmatizer:
	def __init__(self, vocab_dict, Trie, HashMap):
		self.suffixReplacements = {
			'sses': 'ss',
			'ies': 'i',
			'eed': 'ee',
			'ing': '',
			'ed': '',
			's': ''
		}
		self.vowels = ['a', 'e', 'i', 'o', 'u']

		self.vocab_trie = Trie()
		self.vocab_dict = vocab_dict

		self.populateTrie()
		self.results = {}
		self.resultCache = HashMap(500)
		return
	
	def populateTrie(self):
		if (self.vocab_dict is None):
			raise Exception('Expected vocabulary dictionary to form trie from')

		for word in self.vocab_dict:
			try:
				self.vocab_trie.insertString(word.lower())
			except:
				print('Skipping word = ', word.lower())

	def isVowel(self, string = '', index = 0):
		if (len(string) <= index):
			raise Exception(f'Index lies out of range [index = {index}, string = {string}]')

		# a,e,i,o,u and y when preceded by a consonant
		precedingIndexCheck = (index != 0) and ((len(string) - abs(index)) != 0)
		return (string[index] in self.vowels) or (precedingIndexCheck and string[index] == 'y' and (not (string[index - 1] in self.vowels)))

	# Vowel + Consonant = VC
	# Returns the times VC appears
	def getWordMeasure(self, string = ''):
		string = string.lower()
		m = 0
		
		# [C](VC)[V]
		for i in range(0, len(string) - 1):
			if (self.isVowel(string, i) and (not self.isVowel(string, i + 1))):
				m += 1

		return m

	def getConditions(self, string = ''):
		strLen = len(string)
		conditions = ''

		if (strLen > 2 and string[-1] == 's'):
			conditions += 'S'

		cvcCheck = False
		ccCheck = False
		if (strLen >= 3):
			cvcCheck = not self.isVowel(string, -3) and self.isVowel(string, -2) and not self.isVowel(string, -1)

		if (strLen >= 2):
			ccCheck = not self.isVowel(string, -2) and not self.isVowel(string, -1)

		for i in range(0, strLen):
			if (self.isVowel(string, i) and not ('v' in conditions)):
				conditions += 'v'
				break

		if (cvcCheck):
			conditions += 'o'
		
		if (ccCheck):
			conditions += 'd'

		return conditions

	def replaceSuffix(self, string = ''):
		if (len(string) < 2):
			raise Exception('Strings must be greater than 3 characters')

		strLen = len(string)
		i = -2
		stem = None
		suffix = None
		replacementSuffix = None

		if (strLen >= 4):
			i = -4
		elif (strLen >= 3):
			i = -3

		# get length of possible suffix
		for k in range(i, 0):
			if (string[k:] in self.suffixReplacements):
				i = k
				replacementSuffix = self.suffixReplacements[string[k:]]
				break

		if (replacementSuffix is None):
			return string

		stem = string[0:i] # FEED => stem = F
		suffix = string[i:]
		m = self.getWordMeasure(stem)
		conditions = self.getConditions(stem)
		stemHasVowel = 'v' in conditions
		# stemHasD = 'd' in conditions
		stemHasO = 'o' in conditions

		doCleanup = suffix in ['ed', 'ing'] and stemHasVowel

		if (doCleanup):
			if (len(stem) >= 2 and (stem[-2:] in ['at', 'bl'])):
				stem = stem + 'e'
			# skip stemming swimming => swim, asking => as
			#elif (stemHasD and (not (stem[-1] in ['l', 's', 'z']))):
				#stem = stem[0:-1]
			elif (m == 1 and stemHasO):
				stem = stem + 'e'
			elif (stemHasVowel and suffix == 'y'):
				stem = stem + 'i'

		if (not (replacementSuffix is None)):
			if ((m <= 0 and suffix == 'eed') or ((not stemHasVowel) and (suffix in ['ed', 'ing']))):
				return string

			string = stem + replacementSuffix

		# step 2
		#if (m > 0):
		#	if (string[-7:] == 'ational'):
		#		string = string[0:-5] + 'e'
		#	elif (string[-7:] == 'ization'):
		#		string = string[0:-5] + 'e'
		#	elif (string[-6:] == 'biliti'):
		#		string = string[0:-5] + 'le'

		return string

	# don't look for any possible mutations before forming the word	
	def getPossibilities(self, traversalNode = None, word = '', resultant = '', i = 0, cost = 0, addedLength = 0, originalString = ''):
		if ((traversalNode is None) or (len(word) < 2)):
			return -1

		if (traversalNode.endOfWord and (not (resultant in self.results))):
			costFactor = ((len(word) - len(resultant)) + cost, cost)[len(word) < len(resultant)]
			costFactor += ((self.getSimilarityIndex(resultant, originalString) + self.getSimilarityIndex(resultant, word)) / 2) # self.getSimilarityIndex(word, resultant)

			if (costFactor <= 2.3):
				self.results[resultant] = costFactor

		if ((len(word) + addedLength) == i):
			return 0

		# exit if cost exceeds 3 at any point
		if (cost >= 3):
			return 0

		# form the actual word we get first
		if ((i < len(word)) and word[i] in traversalNode.children):
			self.getPossibilities(traversalNode.children[word[i]], word, resultant + word[i], i + 1, cost, addedLength)

		# backtrack to experiment with every possible character
		for childChar in traversalNode.children:
			if ((resultant + childChar) in self.results):
				continue

			self.getPossibilities(traversalNode.children[childChar], word, resultant + childChar, i + 1, cost + 1, addedLength)

		return 0

	def getSimilarityIndex(self, string = '', comparisonString = ''):
		diff = 0

		for i in range(0, len(string)):
			if (i == len(comparisonString)):
				break

			if (string[i] != comparisonString[i]):
				diff += 1

		diff += abs(len(string) - len(comparisonString))

		return diff / len(string)

	def lemmatize(self, string = ''):
		if (len(string) < 2):
			raise Exception('Strings must be greater than 3 characters')

		string = string.lower() # grabs last 4 characters
		stemmedString = self.replaceSuffix(string)
		vocabExists = self.vocab_trie.hasWord(string)
		stemmedVocabExists = self.vocab_trie.hasWord(stemmedString)

		if (stemmedVocabExists):
			return stemmedString

		if ((vocabExists and stemmedString == string)):
			return string

		result = self.resultCache.get(stemmedString)
		if (result is not None):
			return result

		traversalNode = self.vocab_trie.root
		self.getPossibilities(traversalNode, stemmedString, originalString = string, addedLength = 2)
		# tuple = (word, costFactor); tuple[0][0] => first character of the word
		# itemA = itemB
		bestMatches = list(filter(lambda itemA : itemA[0][0] == string[0], sorted(self.results.items(), key = lambda itemB : itemB[1])))

		# print(bestMatches)
		self.results.clear()

		if (len(bestMatches) > 0):
			self.resultCache.put(stemmedString, bestMatches[0][0])
			return bestMatches[0][0]
		
		self.resultCache.put(stemmedString, string)
		return string
