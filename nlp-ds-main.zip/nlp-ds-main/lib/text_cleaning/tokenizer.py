class Tokenizer:
	def __init__(self, HashMap, regex):
		self.stopwords = HashMap(200)
		self.abbreviations = HashMap(100)
		self.re = regex
		self.stopwordsLoaded = False
		self.abbreviationsLoaded = False

	def loadAbbreviations(self, filePath = ''):
		if (len(filePath) < 5):
			raise Exception('File Path should be no less than 5 characters')

		abbreviations = None

		try:
			with open(filePath, 'r', encoding = 'utf-8') as f:
				abbreviations = f.read()
		except:
			raise Exception('Unable to open abbreviations file')

		for abbreviation in (abbreviations.split('\n')):
			try:
				acronym, replacement = abbreviation.split(',')
			except:
				print(f'Incorrectly structured split at {abbreviation}')
			acronym = self.re.sub(r'[^A-Za-z0-9]', '', acronym)
			replacement = self.re.sub(r'[^A-Za-z0-9\s]', '', replacement.lower())
			self.abbreviations.put(acronym, replacement)

		self.abbreviationsLoaded = abbreviations is not None

	def loadStopwords(self, filePath = ''):
		if (len(filePath) < 5):
			raise Exception('File Path should be no less than 5 characters')

		stopwords = None

		try:
			with open(filePath, 'r', encoding = 'utf-8') as f:
				stopwords = f.read()
		except:
			raise Exception('Unable to open stopwords file')

		for stopword in (stopwords.split('\n')):
			self.stopwords.put(stopword, 1)

		self.stopwordsLoaded = stopwords is not None
	
	def tokenize(self, document = ''):
		if (len(document) < 10):
			raise Exception('Document strings should be no less than 10 characters')

		if (not self.abbreviationsLoaded or not self.stopwordsLoaded):
			raise Exception('Abbreviations or Stopwords haven\'t been loaded')

		document = self.re.sub(r'[^A-Za-z\s]', ' ', document)
		tokens = list(filter(lambda item : len(item) >= 2, document.split(' ')))

		for i in range(0, len(tokens)):
			token = tokens[i]

			acronymReplacement = self.abbreviations.get(token)
			if (acronymReplacement is not None):
				tokens[i:i + 1] = acronymReplacement.split(' ')
				continue

		return list(filter(lambda item : self.stopwords.get(item) is None, map(lambda token : token.lower(), tokens)))
