from .scrapers.dynamic_scraper import DynamicScraper as Scraper

class IMDBScraper(Scraper):
	def searchQuery(self, query = ''):
		try:
			self.get('https://www.imdb.com/find?q=' + query)
		except:
			print('Unable to perform the search query')
		
	def getTitleLink(self):
		self.titleLink = self.getElemByXPath('//td[@class="result_text"]/a').get_attribute('href')
		if (len(self.titleLink) < 1):
			return

		self.titleLink = self.titleLink.split('/')
		self.titleLink = '/'.join(self.titleLink[0:-1])
		
	def visitReviews(self):
		try:
			self.get(self.titleLink + '/reviews')
		except:
			print('Unable to visit reviews')

	def loadReviews(self, loadCount = 15):
		pressCount = 0
		
		while ((not self.hasElement('//div[@class="ipl-load-more ipl-load-more--loaded-all"]')) and pressCount < loadCount):
			self.click('//button[@id="load-more-trigger"]')
			self.waitUntilVisible('//div[@class="ipl-load-more ipl-load-more--loaded"]', 'ipl-load-more--loading')
			pressCount += 1

	def expandSpoilers(self, expandCount = 25):
		pressCount = 0
		
		while (pressCount < expandCount):
			self.click('//div[@class="expander-icon-wrapper spoiler-warning__control"]')
			pressCount += 1

	def scrapeReviews(self, query = '', loadCount = 15, expandCount = 25):
		self.searchQuery(query)
		self.getTitleLink()
		self.visitReviews()
		self.loadReviews(loadCount)
		self.expandSpoilers(expandCount)

		# uncomment to also add review titles
		# titles = self.getElementTextByXPath('//div[@class="review-container"]//a[@class="title"]')
		reviews = self.getElementTextByXPath('//div[@class="review-container"]//div[@class="content"]/div[starts-with(@class, "text")]', normalize = True)

		self.quit()

		return reviews