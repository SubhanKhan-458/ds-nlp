class TrieNode:
	def __init__(self, data = ''):
		self.data = data
		self.children = {}
		self.endOfWord = False
		self.stopWord = False
		self.type = ''

class Trie:
	def __init__(self):
		self.root = TrieNode()
		self.wordCount = 0

	def insertString(self, string = '', stopWord = False, type = ''):
		if (len(string) < 2):
			raise Exception('Strings must be greater than 3 characters')

		traversalNode = self.root

		for c in string:
			if (c in traversalNode.children):
				traversalNode = traversalNode.children[c]
				continue
			
			traversalNode.children[c] = TrieNode(c)
			traversalNode = traversalNode.children[c]

		traversalNode.endOfWord = True
		traversalNode.stopWord = stopWord
		traversalNode.type = type
		self.wordCount += 1

	def has(self, string = ''):
		if (len(string) < 2 or self.wordCount <= 0):
			return False

		traversalNode = self.root

		for c in string:
			if (not (c in traversalNode.children)):
				return False
			
			traversalNode = traversalNode.children[c]

		return True

	def hasWord(self, string = ''):
		if (len(string) < 2 or self.wordCount <= 0):
			return False

		traversalNode = self.root

		for c in string:
			if (not (c in traversalNode.children)):
				return False
			
			traversalNode = traversalNode.children[c]

		return traversalNode.endOfWord

	def traverse(self, traversalNode = None, path = ''):
		if (traversalNode is None):
			traversalNode = self.root

		if (not traversalNode.children):
			print(path + traversalNode.data + '$')
			return

		for child in traversalNode.children:
			self.traverse(traversalNode.children[child], path + ((traversalNode.data, '^') [traversalNode.data == '']))
