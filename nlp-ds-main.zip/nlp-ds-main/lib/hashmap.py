class HashNode:
	def __init__(self, key, value, nextNode = None):
		self.key = key
		self.value = value
		self.nextNode = nextNode

class HashMap:
	def __init__(self, size = 50):
		self.size = size
		self.table = [None] * self.size
		self.keys = []
		self.loadFactor = 0.75
		self.insertions = 0

	def put(self, key, value):
		if (type(key) is not str):
			raise Exception(f'HashMap keys should be of type str [received type = {type(key)}]')

		if (self.has(key)):
			index = self.hashFunc(key)
			currentNode = self.table[index]
			while (currentNode is not None and currentNode.key != key):
				currentNode = currentNode.nextNode

			if (currentNode is not None):
				currentNode.value = value

			return

		if (self.exceedsLoadFactor()):
			self.rehash()
		
		index = self.hashFunc(key)
		newNode = HashNode(key, value)

		if (self.table[index] is not None):
			currentNode = self.table[index]
			while (currentNode.nextNode is not None):
				currentNode = currentNode.nextNode

			currentNode.nextNode = newNode
		else:
			self.table[index] = newNode

		self.insertions += 1
		self.keys.append(key)

	def remove(self, key):
		if (type(key) is not str):
			raise Exception(f'HashMap keys should be of type str [received type = {type(key)}]')

		if (key not in self.keys):
			return
		
		index = self.hashFunc(key)

		currentNode = self.table[index]

		# should never happen
		if (currentNode is None):
			return

		if (currentNode.key == key):
			self.table[index] = currentNode.nextNode
		else:
			while (currentNode.nextNode is not None and currentNode.nextNode.key != key):
				currentNode = currentNode.nextNode

			# should also never happen
			if (currentNode.nextNode is None):
				return

			currentNode.nextNode = currentNode.nextNode.nextNode

		self.keys.remove(key)
		self.insertions -= 1

	def has(self, key):
		if (type(key) is not str):
			raise Exception(f'HashMap keys should be of type str [received type = {type(key)}]')

		return key in self.keys

	def get(self, key):
		if (type(key) is not str):
			raise Exception(f'HashMap keys should be of type str [received type = {type(key)}]')

		index = self.hashFunc(key)
		
		if (self.table[index] is not None):
			currentNode = self.table[index]
			if (currentNode.key == key):
				return currentNode.value
			else:
				while (currentNode.nextNode is not None and currentNode.nextNode.key != key):
					currentNode = currentNode.nextNode

				if (currentNode.nextNode is not None):
					return currentNode.nextNode.value
				else:
					return None
		else:
			return None

	def getKeys(self):
		return self.keys

	def exceedsLoadFactor(self):
		return self.insertions >= (self.size * self.loadFactor)

	def rehash(self):
		newSize = self.size * 2 # doubles the size
		rehashedTable = [None] * newSize

		for key in self.keys:
			index = self.hashFunc(key)
			targetNode = self.table[index]

			# should never happen
			if (targetNode is None):
				continue

			if (targetNode.key != key):
				while (targetNode is not None and targetNode.key != key):
					targetNode = targetNode.nextNode

			# should also never happen
			if (targetNode is None):
				continue

			newIndex = self.hashFunc(targetNode.key, newSize)
			newNode = HashNode(targetNode.key, targetNode.value)
			if (rehashedTable[newIndex] is not None):
				rehashedNode = rehashedTable[newIndex]
				while (rehashedNode.nextNode is not None):
					rehashedNode = rehashedNode.nextNode

				rehashedNode.nextNode = newNode
			else:
				rehashedTable[newIndex] = newNode

		self.size = newSize
		self.table = rehashedTable

	def hashFunc(self, key, modConstant = None):
		if (type(key) is not str):
			raise Exception(f'HashMap keys should be of type str [received type = {type(key)}]')

		hashVal = 5381
		if (modConstant is None):
			modConstant = self.size

		for char in key:
			hashVal = ((hashVal << 5) + hashVal) + ord(char)
		
		return (hashVal & 0xFFFFFFFF) % modConstant
