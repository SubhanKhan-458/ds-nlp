from math import log10, floor

class DocumentProcessor:
	def __init__(self, regex, HashMap):
		self.words = {}
		self.totalUniqueWords = 0
		self.re = regex
		self.docsData = []
		self.sentiments = HashMap(2000)
		self.sentimentsLoaded = False
		self.positivityFactor = 0.02
		self.trainingData = {
			'pos': [],
			'neg': [],
			'neu': []
		}

	def loadSentiments(self, filePath = ''):
		if (len(filePath) < 5):
			raise Exception('File Path should be no less than 5 characters')

		sentiments = None

		try:
			with open(filePath, 'r', encoding = 'utf-8') as f:
				sentiments = f.read()
		except:
			raise Exception('Unable to open sentiments file')

		for sentiment in (sentiments.split('\n')):
			try:
				word, val = sentiment.split(',')
			except:
				raise Exception(f'Incorrectly structured split at {sentiment}')
			word = self.re.sub(r'[^A-Za-z0-9]', '', word.lower())
			val = int(val)
			self.sentiments.put(word, val)

		self.sentimentsLoaded = sentiment is not None

	def parseDocument(self, document = []):
		if (len(document) < 1):
			raise Exception(f'Insufficient tokens provided to parseDocument [document = {document}]')

		if (not (self.sentimentsLoaded)):
			raise Exception('Sentiments haven\'t been loaded')

		# prepare doc for TF and sentiment evaluation
		self.docsData.append([{}, 0, 0]) # tokens, number of words, sentiment
		docIndex = len(self.docsData) - 1
		# doc = ({ words... : freq }, sentiment)

		for token in document:
			wSentiment = self.sentiments.get(token)
			tokenSentiment = ((0, wSentiment)[wSentiment is not None])

			if (tokenSentiment == 0):
				continue

			if (token not in self.words):
				self.words[token] = {
					'frequency': 0,
					'sentiment': tokenSentiment,
					'idf': 1,
					'docFreq': 0,
					'lastDocIndex': -1,
					'docsAppearedIn': []
				}
				self.totalUniqueWords += 1
				
			if (token not in self.docsData[docIndex][0]):
				self.docsData[docIndex][0][token] = 0

			if (self.words[token]['lastDocIndex'] != docIndex):
				self.words[token]['docFreq'] += 1
				self.words[token]['lastDocIndex'] = docIndex
				self.words[token]['docsAppearedIn'].append(docIndex)

			self.words[token]['frequency'] += 1
			self.docsData[docIndex][0][token] += 1
			self.docsData[docIndex][1] += 1 # total words

		# calculate tf here
		for token in self.docsData[docIndex][0]:
			# print(f'token = {token}, freq = {self.docsData[docIndex][0][token]}, number of words = {self.docsData[docIndex][1]}')
			self.docsData[docIndex][0][token] /= self.docsData[docIndex][1] # tf

	def removeFrequentTerms(self):
		totalDocs = len(self.docsData)
		
		for token in self.words:
			idf = log10(totalDocs / self.words[token]['docFreq'])
			self.words[token]['idf'] = idf
			for i in self.words[token]['docsAppearedIn']:
				if (idf <= 0):
					# print(f'deleted {token}')
					del self.docsData[i][0][token] # make 0 or del
				else:
					self.docsData[i][0][token] = (self.docsData[i][0][token] * idf) * self.words[token]['sentiment']

	def calcSentiment(self):
		for i in range(0, len(self.docsData)):
			for token in self.docsData[i][0]:
				# print(f'{self.docsData[i][2]} {self.docsData[i][0][token]}')
				self.docsData[i][2] += self.docsData[i][0][token]

			# > positivityFactor => positive | < 0 => negative | 0 <= sentiment < positivityFactor => neutral
			sentiment = self.docsData[i][2]
			# print(f'Review: {self.docsData[i][0]}\nSentiment score: {sentiment}')
			result = 'neg'
			if (sentiment >= -0.25 and sentiment <= 0.25):
				result = 'neu'
			else:
				if (sentiment >= self.positivityFactor):
					result = 'pos'
			# elif (sentiment < 0):
			# 	result = 'negative'

			self.docsData[i].append(result)
			# print(f'\n\n{i} {result} {self.docsData[i]}\n\n')
			del self.docsData[i][1:3]

	def featurizeDocs(self):
		for token in self.words:
			for i in range(0, len(self.docsData)):
				self.docsData[i][0][token] = (token in self.docsData[i][0])

		for doc in self.docsData:
			if (doc[1] == 'pos'):
				self.trainingData['pos'].append((doc[0], doc[1]))
			elif (doc[1] == 'neg'):
				self.trainingData['neg'].append((doc[0], doc[1]))
			else:
				self.trainingData['neu'].append((doc[0], doc[1]))


	def makeFeatureSet(self, document = []):
		if (len(document) < 1):
			raise Exception(f'Insufficient number of tokens provided to makeFeatureSet [document = {document}]')

		featureSet = {}
		for token in self.words:
			featureSet[token] = (token in document)

		return featureSet

	def processDocuments(self, documents = []):
		if (len(documents) < 1):
			raise Exception('Insufficient document number to load')

		for doc in documents:
			self.parseDocument(doc)

		self.removeFrequentTerms()
		self.calcSentiment()
		self.featurizeDocs()

		totalPosDocs = len(self.trainingData['pos'])
		totalNegDocs = len(self.trainingData['neg'])
		# totalNeuDocs = len(self.trainingData['neu'])
		avgDocCountPerSentiment = floor((totalPosDocs + totalNegDocs) / 2)

		if (avgDocCountPerSentiment > totalPosDocs):
			posDocs = self.trainingData['pos']
		else:
			posDocs = self.trainingData['pos'][0:avgDocCountPerSentiment]

		if (avgDocCountPerSentiment > totalNegDocs):
			negDocs = self.trainingData['neg']
		else:
			negDocs = self.trainingData['neg'][0:avgDocCountPerSentiment]

		# if (avgDocCountPerSentiment > totalNeuDocs):
		# 	neuDocs = self.trainingData['neu']
		# else:
		# 	neuDocs = self.trainingData['neu'][0:avgDocCountPerSentiment]

		# return (self.trainingData['pos'] + self.trainingData['neg'])
		return (posDocs + negDocs)