class StaticScraper:
	"""
	Used for scraping

	-----------------
	Attributes
	-----------------
	requests: requests package (object)
	beautiful_soup: beautiful_soup package (BeautifulSoup - object)
	regex: re library (object)

	-----------------
	Methods
	-----------------
	scrape(url = None, file_name = 'words.csv')
		scrapes a URL, splits the text and stores it in a csv
	fetch_text(url = None)
		sends a GET request and gets text from a URL
	parse_text(body = None)
		parses the body fetched from fetch_text, using beautiful_soup
	strip_text(text = None)
		strips the text of all non-alphabetical characters, excluding apostrophe, period and whitespaces
	split_words(text = None)
		splits the text into a list using the whitespace as a separator
	filter_whitespace(word_list = None)
		filters the word_list for elements with more than 1 character
	write_to_csv(file_name = 'words.csv', word_list = [])
		writes the word_list to a csv file

	"""

	def __init__(self, requests, beautiful_soup, regex):
		self.req = requests
		self.bs4 = beautiful_soup
		self.re = regex

	def scrape(self, url = None, file_name = 'words.csv'):
		if (url is None):
			raise Exception('URL is a required argument')

		body = self.fetch_text(url)
		text = self.parse_text(body)
		text = self.strip_text(text)
		word_list = self.split_words(text)
		word_list = self.filter_whitespace(word_list)
		
		self.write_to_csv(file_name, word_list)


	def fetch_text(self, url = None):	
		res = self.req.get(url)
		if (res.status_code != 200):
			return ''
		
		return res.text

	def parse_text(self, body = None):
		if (body is None):
			return ''
		
		return self.bs4(body, 'html.parser').get_text()

	def strip_text(self, text = None):
		if (text is None):
			return ''

		# pylint: disable=fixme, anomalous-backslash-in-string
		return self.re.sub('[^A-Za-z.\'\s]', '', text)
	
	def split_words(self, text = None):
		if (text is None):
			return []

		return text.split()

	def filter_whitespace(self, word_list = None):
		if (word_list is None):
			return []
		
		return filter(lambda word: len(word) > 1, word_list)

	def write_to_csv(self, file_name = 'words.csv', word_list = []):
		f = None

		try:
			f = open(file_name, 'w')
		except OSError:
			print('Unable to write')
			return
		
		f.write('\n'.join(word_list))
		
		f.close()

