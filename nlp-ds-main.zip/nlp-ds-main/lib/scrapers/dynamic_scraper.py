class DynamicScraper:
	# selenium.webdriver, selenium.webdriver.support.expected_conditions, re
	def __init__(self, webdriver, expectedConditions, selExceptions, regex):
		self.web_driver = webdriver
		try:
			self.driver = webdriver.Chrome()
		except:
			print('Unexpected error during session creation for Chrome Driver')
		self.driverWait = webdriver.support.ui.WebDriverWait
		self.driverEC = expectedConditions
		self.locateBy = webdriver.common.by.By
		self.waitTime = 3
		self.driver.implicitly_wait(self.waitTime)
		self.re = regex
		self.exceptions = selExceptions

	def get(self, url = ''):		
		if (len(url) < 10):
			raise Exception('URLs should be no less than 10 characters')

		try:
			self.driver.get(url)
		except self.exceptions.WebDriverException:
			self.driver = self.web_driver.Chrome()
		except:
			print('Unexpected argument provided to DynamicScraper#get')
		
	def getElemByClass(self, class_name = ''):
		if (len(class_name) < 2):
			raise Exception('Class selectors should be no less than 2 characters')

		return self.driver.find_element_by_class_name(class_name)

	def getElemByXPath(self, xpath = ''):
		if (len(xpath) < 2):
			raise Exception('Xpath should be no less than 2 characters')

		return self.driver.find_element_by_xpath(xpath)

	def getElementsByXPath(self, xpath = ''):
		if (len(xpath) < 2):
			raise Exception('Xpath should be no less than 2 characters')

		return self.driver.find_elements_by_xpath(xpath)

	def getElementTextByXPath(self, xpath = '', normalize = False):
		if (len(xpath) < 2):
			raise Exception('Xpath should be no less than 2 characters')

		elements = self.getElementsByXPath(xpath)
		return [(element.text, self.normalizeElementText(element.text))[int(normalize)] for element in elements if (element.text and len(element.text) > 0)]

	def normalizeElementText(self, text):
		# if (len(text) < 2):
		# 	raise Exception('Strings should be no less than 2 characters')

		if (len(text) <= 0):
			return text

		# remove links
		text = self.re.sub(r'(http|https):\/{2}[\d\w-]+(\.[\d\w-]+)*(?:(?:\/[^\s/]*))*', '', text) # http(s) links
		text = self.re.sub(r'<a[^>]*>(.*?)<\/a>', '', text) # a tags
		text = self.re.sub(r'[^a-z.,!?;"\'\s]', '', text, flags = self.re.I)
		return self.re.sub(r'\s\s+', ' ', text)

	def click(self, xpath = ''):
		if (len(xpath) < 2):
			raise Exception('Xpath should be no less than 2 characters')

		clickable = None
		try:
			clickable = self.driverWait(self.driver, self.waitTime).until(self.driverEC.element_to_be_clickable((self.locateBy.XPATH, xpath)))
		except:
			print('Unable to find clickable element at xpath=' + xpath)
		finally:
			if (not (clickable is None)):
				clickable.click()

		return clickable

	def waitUntilVisible(self, xpath = '', waitForClassName = ''):
		if (len(xpath) < 2 or len(waitForClassName) < 2):
			raise Exception('Xpath and Xpath should be no less than 2 characters')

		tempEl = None
		try:
			tempEl = self.driverWait(self.driver, self.waitTime).until(self.driverEC.visibility_of_element_located((self.locateBy.XPATH, xpath)))
			self.driverWait(self.driver, self.waitTime).until(lambda word: waitForClassName not in tempEl.get_attribute('class'))
		except:
			print('Unable to find element at xpath=' + xpath)

	def hasElement(self, xpath = ''):
		if (len(xpath) < 2):
			raise Exception('Xpath should be no less than 2 characters')

		element = None
		try:
			element = self.driverWait(self.driver, self.waitTime).until(self.driverEC.visibility_of_element_located((self.locateBy.XPATH, xpath)))
		except:
			print('Unable to find element at xpath=' + xpath)
		finally:
			return element is not None

	def quit(self):
		self.driver.quit()
