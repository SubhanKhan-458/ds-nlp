# NLP-DS

## Installation / Set-up

To get started, you need to have ``python 3.x`` installed, and ``pip 20.2.x``. Next you need to install the packages mentioned below (in no particular order).

### Packages
- ``selenium``
	- Install the relevant chromium driver (same version as your Chrome)
	- Add the path to the chromium driver executable to your PATH in environment variables
- ``nltk``
- ``Flask``