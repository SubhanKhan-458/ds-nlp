from os import SEEK_END, SEEK_SET
from flask import Flask, request, jsonify

from selenium import webdriver
from selenium.webdriver.support import expected_conditions as EC
from selenium.common import exceptions as SelExcepts
import re
import json

from lib.imdbScraper import IMDBScraper as Scraper
from lib.hashmap import HashMap
from lib.trie import Trie
from lib.text_cleaning.tokenizer import Tokenizer
from lib.text_cleaning.lemmatizer import Lemmatizer
from lib.text_classification.doc_processor import DocumentProcessor
from nltk import classify, accuracy
from random import shuffle

# Initialize Tokenizer
TokenizerInstance = Tokenizer(HashMap, re)
TokenizerInstance.loadAbbreviations('./data/abbreviations.csv')
TokenizerInstance.loadStopwords('./data/stopwords.csv')

# Initialize Lemmatizer
LemmatizerInstance = None
with open('./data/word_list.json', 'r', encoding = 'utf-8') as f:
	LemmatizerInstance = Lemmatizer(json.load(f), Trie, HashMap)

if (LemmatizerInstance is None):
	raise Exception('Unable to initialize lemmatizer')

# Initialize Document Processor
DocProcInstance = DocumentProcessor(re, HashMap)
DocProcInstance.loadSentiments('./data/sentiments.csv')

# Initialize Classifier
classifier = classify.NaiveBayesClassifier

# Model Instance
model = None

app = Flask(__name__)

@app.route('/scrape', methods = ['POST'])
def scrape():
	if (not request.is_json):
		return jsonify({ 'success': False, 'message': 'Expected a JSON payload' }), 400
	
	payload = request.get_json()
	if (payload is None):
		return jsonify({ 'success': False, 'message': 'Unable to process the request' }), 400

	title = payload.get('title')
	if (title is None or len(title) < 2):
		return jsonify({ 'success': False, 'message': 'Invalid movie title provided' }), 400

	loadCount = payload.get('load_review_count')
	expandCount = payload.get('spoiler_expand_count')
	if (loadCount is None or (not isinstance(loadCount, (int))) or loadCount < 5):
		loadCount = 15
	if (expandCount is None or (not isinstance(expandCount, (int))) or expandCount < 10):
		expandCount = 25

	ScraperInstance = Scraper(webdriver, EC, SelExcepts, re)
	reviews = ScraperInstance.scrapeReviews(title, loadCount, expandCount)

	if (len(reviews) <= 0):
		return jsonify({ 'success': False, 'message': 'Insufficient review count' }), 400

	processedTokens = []
	buffer = []
	for review in reviews:
		tokens = TokenizerInstance.tokenize(review)
		for token in tokens:
			lemma = LemmatizerInstance.lemmatize(token)
			buffer.append(lemma)

		processedTokens.append(', '.join(buffer))
		buffer = []

	with open('./data/training_data.csv', 'a', encoding = 'utf-8') as f:
		f.write('\n\n')
		f.write('\n\n'.join(processedTokens))
	
	return jsonify({ 'success': True }), 200

@app.route('/train', methods = ['POST'])
def train():
	global model
	if (not request.is_json):
		return jsonify({ 'success': False, 'message': 'Expected a JSON payload' }), 400
	
	payload = request.get_json()
	if (payload is None):
		return jsonify({ 'success': False, 'message': 'Unable to process the request' }), 400

	pin = payload.get('pin')
	if (pin is None or len(pin) < 2 or pin != '112134@AbcXdWppoZ'):
		return jsonify({ 'success': False, 'message': 'Invalid PIN provided' }), 400

	try:
		# read training data
		documents = None
		with open('./data/training_data.csv', 'r', encoding = 'utf-8') as f:
			documents = f.read()

		documents = documents.split('\n\n')
		documents = list(map(lambda tokens : tokens.split(', '), documents))

		# process documents
		processedDocs = DocProcInstance.processDocuments(documents)
		shuffle(processedDocs)

		# separate training data & test data
		docCount = len(processedDocs)
		trainingData = processedDocs[0 : int(docCount / 2)]
		testData = processedDocs[int(docCount / 2) + 1 : docCount]

		# train model
		model = classifier.train(trainingData)

		# calculate accuracy
		accuracy = classify.accuracy(model, testData)

		return jsonify({ 'success': True, 'accuracy': accuracy }), 200
	except:
		return jsonify({ 'success': False, 'message': 'Something went wrong when training the model, check logs for more details...'}), 418 # teapot

@app.route('/classify', methods = ['POST'])
def getSentiment():
	global model
	if (not request.is_json):
		return jsonify({ 'success': False, 'message': 'Expected a JSON payload' }), 400
	
	payload = request.get_json()
	if (payload is None):
		return jsonify({ 'success': False, 'message': 'Unable to process the request' }), 400

	document = payload.get('document')
	if (document is None or (not isinstance(document, (str))) or len(document) < 2):
		return jsonify({ 'success': False, 'message': 'Bad review provided' }), 400

	if (model is None):
		return jsonify({ 'success': False, 'message': 'Model is not trained; Send a POST request to `/train` endpoint'}), 400

	try:
		document = TokenizerInstance.tokenize(document)
		document = list(map(lambda token : LemmatizerInstance.lemmatize(token), document))
		document = DocProcInstance.makeFeatureSet(document)

		label = model.classify(document)

		return jsonify({ 'success': True, 'label': label }), 200
	except:
		return jsonify({ 'success': False }), 400

if __name__ == '__main__':
	app.run(host = '0.0.0.0', debug = True, port = 8000)
